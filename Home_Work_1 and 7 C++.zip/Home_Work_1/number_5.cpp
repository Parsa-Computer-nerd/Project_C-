#include <iostream>
using namespace std;

main()
{
    int n;
    float sum = 1.0, Fact = 1;

    cout << "Enter number : ";
    cin >> n;

    for (int i = 1; i <= n - 1; i++)
    {
        Fact *= (float)(1.0 / i);
        sum += Fact;
    }
    cout << "sum : " << sum;
}
