#include <iostream>
using namespace std;

int main()
{
    int n, a = 0, b = 1, Fib = 0;

    cout << "Enter number : ";
    cin >> n;

    for (int i = 1; i <= n; i++)
    {
        if (n >= Fib)
        {
            cout << Fib << "\t";
            a = b;
            b = Fib;
            Fib = a + b;
        }
        else
        {
            break;
        }
    }
}
