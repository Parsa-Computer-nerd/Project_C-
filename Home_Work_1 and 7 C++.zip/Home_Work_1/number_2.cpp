#include <iostream>
using namespace std;

int main()
{
    int x, y, plase = 1, result = 0;

    cout << "Enter number : ";
    cin >> x;

    do
    {
        y = x % 10;
        x = x / 10;
        if (y % 2 == 0)
        {
            result += 0 * plase;
        }
        else
        {
            result += 1 * plase;
        }
        plase *= 10;
    } while (x != 0);
    cout << result;
}
