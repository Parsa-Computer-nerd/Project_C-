#include <iostream>
using namespace std;

main()
{
    int n, i;
    float sum = 0;

    cout << "Enter number : ";
    cin >> n;

    for (i = 1; i <= n; i++)
    {
        sum += (i / (float)(i + 1));
    }
    cout << "sum : " << sum << endl;
}
