#include <iostream>
using namespace std;

main()
{
    for (int i = 2; i <= 8; i += 2)
    {
        for (int j = 0; j <= 8; j += 2)
        {
            for (int k = 0; k <= 8; k += 2)
            {
                cout << i << j << k << endl;
            }
        }
    }
}
