#include <iostream>
using namespace std;

main()
{
    int a, b, i, j, x = 0;

    cout << "Enter number one : ";
    cin >> a;
    cout << "Enter number two : ";
    cin >> b;

    if (a > b)
    {
        for (i = b + 1; i < a; i++)
        {
            x = 0;
            for (j = 1; j <= i; j++)
            {
                if (i % j == 0)
                {
                    x++;
                }
            }
            if (x == 2)
            {
                cout << i << endl;
            }
        }
    }
    else
    {
        for (i = a + 1; i < b; i++)
        {
            x = 0;
            for (j = 1; j <= i; j++)
            {
                if (i % j == 0)
                {
                    x++;
                }
            }
            if (x == 2)
            {
                cout << i << endl;
            }
        }
    }
}