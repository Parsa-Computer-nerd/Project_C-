#include <iostream>
using namespace std;

int main()
{
    int n, z = 0;
    cout << "Enter number : ";
    cin >> n;

    while (n != 0)
    {
        z = z * 10 + (n % 10);
        n /= 10;
    }

    cout << z;

}
